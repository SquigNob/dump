function DashboardViewModel() {
    var self = this;

    self.AtooErrors = ko.observable(0);
    self.AtooStatus = ko.observable("");
    self.AtooUnreliable = ko.observable(false);
    self.AtooActiveUsers = ko.observable(0);
    self.AtooMyTaxCurrentPeriodLodgmentsToday = ko.observable(0);
    self.AtooJobKeeperLodgmentsToday = ko.observable(0);
    self.AtooEsrbLodgmentsToday = ko.observable(0);
    self.AtooTopPages = ko.observableArray();
    self.AtooWaitingRoomUsers = ko.observable(0);
    self.AtooWaitingRoomUsersCount = ko.observable(0);

    self.LreErrors = ko.observable(0);
    self.LreStatus = ko.observable("");
    self.LreUnreliable = ko.observable(false);
    self.LreLandingPages = ko.observable(0);
    self.LreActiveUsers = ko.observable(0);

    self.BPErrors = ko.observable(0);
    self.BPStatus = ko.observable("");
    self.BPUnreliable = ko.observable(false);
    self.BPLandingPages = ko.observable(0);
    self.BPActiveUsers = ko.observable(0);

    self.OsbErrors = ko.observable(0);
    self.OsbStatus = ko.observable("");
    self.OsbUnreliable = ko.observable(false);
    self.OsbLandingPages = ko.observable(0);
    self.OsbActiveUsers = ko.observable(0);

    self.OsfaErrors = ko.observable(0);
    self.OsfaStatus = ko.observable("");
    self.OsfaUnreliable = ko.observable(false);
    self.OsfaLandingPages = ko.observable(0);
    self.OsfaActiveUsers = ko.observable(0);
    self.OsfaJobKeeperLodgmentsToday = ko.observable(0);
    self.OsfaTopPages = ko.observableArray();
    self.OsfaWaitingRoomUsers = ko.observable(0);
    self.OsfaWaitingRoomUsersCount = ko.observable(0);

    self.AtoGovErrors = ko.observable(0);
    self.AtoGovStatus = ko.observable("");
    self.AtoGovUnreliable = ko.observable(false);
    self.AtoGovActiveUsers = ko.observable(0);
    self.AtoGovTopPages = ko.observableArray();

    self.UpdateTime = ko.observable();
    self.Errors = ko.observableArray();
    self.config = ko.observable();

    self.ErrorText = ko.pureComputed(function () {
        var count = this.Errors().length;
        return count + " Error" + (count > 1 ? "s" : "");
    }, self);

    self.previousFinancialYear = ko.pureComputed(function () {
        var date = new moment().subtract(1, 'years');
        return date.month() > 5 ? date.add(1, "years").format("YY") : date.format("YY");
    });

    self.HistoryLastWeek = [];
    self.HistoryYesterday = [];
    self.HistoryToday = [];

    self.RecentBPActiveUsers = [];
    self.RecentLreActiveUsers = [];
    self.RecentAtooActiveUsers = [];
    self.RecentOsbActiveUsers = [];
    self.RecentOsfaActiveUsers = [];
    self.RecentAtoGovActiveUsers = [];

    self.startup = function () {
        self.retriveConfig();
        self.loadData();
    };

    self.loadData = function () {
        if (self.config() !== undefined) {
            self.loadRealTimeJson();
            self.loadDailyJson();
            self.loadHourlyJson();
        }
        else {
            window.setTimeout(function () { self.loadData(); }, 500);
        }
        if (self.HistoryLastWeek.Lodgments === undefined ||
            self.HistoryYesterday.Lodgments === undefined ||
            self.HistoryToday.Lodgments === undefined) {
            window.setTimeout(function () { self.drawChart(); }, 1000);
        } else {
            self.drawChart();
        }
    };

    self.loadRealTimeJson = function () {
        if (self.config() !== undefined) {
            var url = self.config().UrlRoot + 'stats.json?' + self.config().AuthToken + '&nocache=' + (new Date()).getTime();
            $.getJSON(url, function (data) {
                processJSON(data);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log(textStatus);
                console.log(errorThrown);
            });
        }
    };

    self.loadHourlyJson = function () {
        if (self.config() !== undefined) {
            var url = self.config().UrlRoot + 'today.json?' + self.config().AuthToken + '&nocache=' + (new Date()).getTime();
            $.getJSON(url, function (data) {
                self.HistoryToday = data;
                self.drawChart();
            }).fail(function (jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log(textStatus);
                console.log(errorThrown);
            });
        }

        window.setTimeout(function () { self.loadHourlyJson(); }, 3600000);
    };

    self.loadDailyJson = function () {
        if (self.config() !== undefined) {
            var url = self.config().UrlRoot + 'historic/' + new moment().subtract(1, 'days').format('YYYY-MM-DD') + '.json?' + self.config().AuthToken;
            $.getJSON(url, function (data) {
                self.HistoryYesterday = data;
                CheckData(self.HistoryYesterday);
                self.drawChart();
            }).fail(function (jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log(textStatus);
                console.log(errorThrown);
            });

            url = self.config().UrlRoot + 'historic/' + new moment().subtract(7, 'days').format('YYYY-MM-DD') + '.json?' + self.config().AuthToken;
            $.getJSON(url, function (data) {
                self.HistoryLastWeek = data;
                CheckData(self.HistoryLastWeek);
                self.drawChart();
            }).fail(function (jqXHR, textStatus, errorThrown) {
                console.log(jqXHR);
                console.log(textStatus);
                console.log(errorThrown);
            });
        }

        window.setTimeout(function () { self.loadDailyJson(); }, 86400000);
    };

    self.retriveConfig = function () {
        var dataSouce = 'config.json?nocache=' + (new Date()).getTime();
        $.getJSON(dataSouce, function (data) {
            self.config(data);
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        });
    };

    self.drawChart = function () {
        var hours = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 ];

        var options = {
            showPoint: true,
            lineSmooth: true,
            axisX: {
                showGrid: false,
                showLabel: false
            },
            fullWidth: true,
            chartPadding: 0
        };

        var atooUsersData = {
            labels: hours,
            series: [
                self.HistoryLastWeek.AtooUsers,
                self.HistoryYesterday.AtooUsers,
                self.HistoryToday.AtooUsers
            ]
        };
        new Chartist.Line('#atooUsersChart', atooUsersData, options);

        var atooLodgmentData = {
            labels: hours,
            series: [
                self.HistoryLastWeek.AtooLodgments,
                self.HistoryYesterday.AtooLodgments,
                self.HistoryToday.AtooLodgments,
                self.HistoryLastWeek.AtooEsrb,
                self.HistoryYesterday.AtooEsrb,
                self.HistoryToday.AtooEsrb,
                //self.HistoryLastWeek.AtooJobKeeper,
                //self.HistoryYesterday.AtooJobKeeper,
                //self.HistoryToday.AtooJobKeeper
            ]
        };
        new Chartist.Line('#atooLodgmentChart', atooLodgmentData, options);

        var osfaUsersData = {
            labels: hours,
            series: [
                self.HistoryLastWeek.OsfaUsers,
                self.HistoryYesterday.OsfaUsers,
                self.HistoryToday.OsfaUsers
            ]
        };
        new Chartist.Line('#osfaUsersChart', osfaUsersData, options);

        var osfaLodgmentData = {
            labels: hours,
            series: [
                self.HistoryLastWeek.OsfaJobKeeper,
                self.HistoryYesterday.OsfaJobKeeper,
                self.HistoryToday.OsfaJobKeeper
            ]
        };
        new Chartist.Line('#osfaLodgmentChart', osfaLodgmentData, options);
    };

    self.ShowErrors = function () {
        document.getElementById('errors').classList.toggle('hidden');
        return false;
    };

    function processJSON(data) {
        self.UpdateTime(data.retrieved);
        self.Errors(data.errors);
        var applications = data.applications;

        var rate = 0;
        if (self.config() !== undefined) {
            rate = self.config().RoundUpRate;
        }

        applications.forEach(function (app) {
            if (app.name === "BP") {
                self.BPActiveUsers(numberWithCommas(app.details.activeUsers));
                self.BPLandingPages(numberWithCommas(app.details.landingPages));
                self.BPErrors(getRate(app.details.activeUsers, app.details.errors));
                self.BPStatus(getClass(app.details.activeUsers, app.details.errors));

                //only check when BP user is over 400
                if (app.details.activeUsers > 400) {
                    self.RecentBPActiveUsers.push(app.details.activeUsers);
                    self.BPUnreliable(isUnreliable(self.RecentBPActiveUsers));
                } else {
                    self.BPUnreliable(false);
                }
            }
            if (app.name === "Lre") {
                self.LreActiveUsers(numberWithCommas(app.details.activeUsers));
                self.LreLandingPages(numberWithCommas(app.details.landingPages));
                self.LreErrors(getRate(app.details.activeUsers, app.details.errors));
                self.LreStatus(getClass(app.details.activeUsers, app.details.errors));

                //only check when LRE user is over 100
                if (app.details.activeUsers > 100) {
                    self.RecentLreActiveUsers.push(app.details.activeUsers);
                    self.LreUnreliable(isUnreliable(self.RecentLreActiveUsers));
                } else {
                    self.LreUnreliable(false);
                }
            }
            if (app.name === "Osb") {
                self.OsbActiveUsers(numberWithCommas(app.details.activeUsers));
                self.OsbLandingPages(numberWithCommas(app.details.landingPages));
                self.OsbErrors(getRate(app.details.activeUsers, app.details.errors));
                self.OsbStatus(getClass(app.details.activeUsers, app.details.errors));

                //only check when BP user is over 400
                if (app.details.activeUsers > 400) {
                    self.RecentBPActiveUsers.push(app.details.activeUsers);
                    self.BPUnreliable(isUnreliable(self.RecentBPActiveUsers));
                } else {
                    self.BPUnreliable(false);
                }
            }
            if (app.name === "Osfa") {
                self.OsfaActiveUsers(numberWithCommas(app.details.activeUsers));
                self.OsfaLandingPages(numberWithCommas(app.details.landingPages));
                self.OsfaErrors(getRate(app.details.activeUsers, app.details.errors));
                self.OsfaStatus(getClass(app.details.activeUsers, app.details.errors));

                //only check when OSFA user is over 2000
                if (app.details.activeUsers > 2000) {
                    self.RecentOsfaActiveUsers.push(app.details.activeUsers);
                    self.OsfaUnreliable(isUnreliable(self.RecentOsfaActiveUsers));
                } else {
                    self.OsfaUnreliable(false);
                }

                self.OsfaTopPages(app.details.topPages.slice(0, 5));
                self.OsfaWaitingRoomUsersCount(app.details.waitingRoomUsers);
                self.OsfaWaitingRoomUsers(numberWithCommas(app.details.waitingRoomUsers));

                var osfaJobKeeperLodgments = parseInt(app.details.jobKeeperLodgmentsToday * (1 + rate));
                self.OsfaJobKeeperLodgmentsToday(numberWithCommas(osfaJobKeeperLodgments));
            }
            if (app.name === "Atoo") {
                self.AtooActiveUsers(numberWithCommas(app.details.activeUsers));
                self.AtooErrors(getRate(app.details.activeUsers, app.details.errors));
                self.AtooStatus(getClass(app.details.activeUsers, app.details.errors));

                //only check when ATOO user is over 2000
                if (app.details.activeUsers > 2000) {
                    self.RecentAtooActiveUsers.push(app.details.activeUsers);
                    self.AtooUnreliable(isUnreliable(self.RecentAtooActiveUsers));
                } else {
                    self.AtooUnreliable(false);
                }

                self.AtooTopPages(app.details.topPages.slice(0, 5));
                self.AtooWaitingRoomUsersCount(app.details.waitingRoomUsers);
                self.AtooWaitingRoomUsers(numberWithCommas(app.details.waitingRoomUsers));

                var myTaxLodgmentsToday = parseInt(app.details.myTaxCurrentPeriodLodgmentsToday * (1 + rate));
                self.AtooMyTaxCurrentPeriodLodgmentsToday(numberWithCommas(myTaxLodgmentsToday));
                var atooEsrbLodgmentsToday = parseInt(app.details.esrbLodgmentsToday * (1 + rate));
                self.AtooEsrbLodgmentsToday(numberWithCommas(atooEsrbLodgmentsToday));
                var atooJobKeeperLodgments = parseInt(app.details.jobKeeperLodgmentsToday * (1 + rate));
                self.AtooJobKeeperLodgmentsToday(numberWithCommas(atooJobKeeperLodgments));
            }
            if (app.name === "AtoGov") {
                self.AtoGovActiveUsers(numberWithCommas(app.details.activeUsers));
                self.AtoGovErrors(getRate(app.details.activeUsers, app.details.errors));
                self.AtoGovStatus(getClass(app.details.activeUsers, app.details.errors));

                //only check when Ato.gov user is over 2000
                if (app.details.activeUsers > 400) {
                    self.RecentAtoGovActiveUsers.push(app.details.activeUsers);
                    self.AtoGovUnreliable(isUnreliable(self.RecentAtoGovActiveUsers));
                } else {
                    self.AtoGovUnreliable(false);
                }

                self.AtoGovTopPages(app.details.topPages.slice(0, 5));
            }
        });
    }

    function CheckData(data) {

        if (data.AtooUsers === undefined) {
            data.AtooUsers = [];
        }

        if (data.AtooEsrb === undefined) {
            data.AtooEsrb = [];
        }

        if (data.AtooJobKeeper === undefined) {
            data.AtooJobKeeper = [];
        }

        if (data.OsfaUsers === undefined) {
            data.OsfaUsers = [];
        }

        if (data.OsfaJobKeeper === undefined) {
            data.OsfaJobKeeper = [];
        }
    }

    function numberWithCommas(x) {
        return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    function getRate(total, error) {
        var errorText = numberWithCommas(error);
        if (total !== 0) {
            var rate;
            rate = 100 * (error / total);
            //no decial ponint number for over 10 rate
            if (rate < 10) {
                rate = rate.toFixed(1);
                //rate is shown only if it is over 0.5
                if (rate > 0.5) {
                    errorText = numberWithCommas(error) + ' (' + rate + '%)';
                }
            } else {
                rate = rate.toFixed(0);
                errorText = numberWithCommas(error) + ' (' + rate + '%)';
            }
        }

        return errorText;
    }

    function getClass(total, error) {
        if (total === 0) { return "value normal"; }

        rate = 100 * (error / total);

        if (rate > 5) { return "value errors"; }

        if (rate < 2) { return "value normal"; }

        return "value warning";
    }

    function error(jqXHR, textStatus, errorThrown) {
        console.log(jqXHR);
        console.log(textStatus);
        console.log(errorThrown);
    }

    function isUnreliable(userArray) {
        var returnValue = false;

        if (userArray.length >= 2) {
            // bigger then previous
            if (userArray[userArray.length - 2] < userArray[userArray.length - 1]) {
                // value increased 15 times in a row
                if (userArray.length === 15) {
                    returnValue = true;
                    userArray.shift();
                }
            }
            // equal
            else if (userArray[userArray.length - 2] === userArray[userArray.length - 1]) {
                if (userArray.length === 15) {
                    returnValue = true;
                }
                userArray.pop();
            }
            // not increasing
            else {
                userArray.length = 0;
            }
        }

        return returnValue;
    }
}

var now = new moment();
var daily = new moment().endOf('day').add(10, "m");
var hourly = new moment().endOf('hour').add(5, 'm');

var vm = new DashboardViewModel();

window.setInterval(function () { vm.loadRealTimeJson(); }, 15000);
window.setTimeout(function () { vm.loadHourlyJson(); }, now.diff(hourly));
window.setTimeout(function () { vm.loadDailyJson(); }, now.diff(daily));

document.addEventListener("DOMContentLoaded", function (event) {
    vm.startup();
    ko.applyBindings(vm);
});

window.addEventListener('resize', function (event) {
    vm.drawChart();
});
